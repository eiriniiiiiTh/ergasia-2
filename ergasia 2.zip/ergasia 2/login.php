<?php
	// Ξεκινάμε τη συνεδρία PHP
	session_start();
	// Απαιτούμε το αρχείο db.php για τη σύνδεση στη βάση δεδομένων
	require 'db.php';

	
	
	// Έλεγχος αν η αίτηση είναι τύπου POST
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		// Λαμβάνουμε τα δεδομένα από τη φόρμα εισόδου
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		// Εκτελούμε ερώτημα SQL για την εύρεση του χρήστη βάσει του email
		$query = "SELECT id, fname, lname, password, id_role FROM users WHERE email=?";
		$stmt = $conn->prepare($query);
		$stmt->bind_param("s", $email);
		$stmt->execute();
		$result = $stmt->get_result();
		
		// Αν υπάρχει μόνο ένας χρήστης με αυτό το email
		if ($result->num_rows == 1) {
			$row = $result->fetch_assoc();
			// Ελέγχουμε αν ο κωδικός είναι σωστός χρησιμοποιώντας τη συνάρτηση password_verify
			if (password_verify($password, $row['password'])) {
				// Αποθηκεύουμε στη συνεδρία τα στοιχεία του συνδεδεμένου χρήστη
				$_SESSION['user_id'] = $row['id'];
				$_SESSION['user_fname'] = $row['fname'];
				$_SESSION['user_role'] = $row['id_role'];
				// Ανάλογα με το ρόλο του χρήστη, τον ανακατευθύνουμε στην κατάλληλη σελίδα
				if ($row['id_role'] == 1) {
					header("Location: admin.php");
					} else {
					// Κάτι πήγε στραβά με τον ρόλο του χρήστη, μπορείτε να αντιμετωπίσετε αυτό κατάλληλα
					// Εδώ μπορείτε να κατευθύνετε τον χρήστη σε μια προεπιλεγμένη σελίδα
					header("Location: index.php");
				}
				exit();
				} else {
				$error = "Invalid email or password";
			}
			} else {
			$error = "Invalid email or password";
		}
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Login</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
		<link rel="stylesheet" href="style.css">
		<style>

            body {

            background-image: url('images/eikona1.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center top 0px;
                }

			h1 {
            color: black;

        }
		.form-label {
            color: black;
        }

        .form-control {
            color: white;
            background-color: transparent;
            /* Αν θες να είναι διάφανα */
            border: 1px solid white;
            /* Ορίζει άσπρο περίγραμμα */
            padding: 5px;
            margin-bottom: 10px;
        }

        .btn-primary {
            background-color: darkred;
            /* Κάνει το κουμπί κόκκινο */
            border: none;
            color: black;
        }

        .btn-primary:hover {
            background-color: darkred;
            /* Αλλάζει το χρώμα στο hover */
        }

        .btn-link {
            color: darkred;
            /* Κάνει το link κόκκινο */
        }

        .btn-link:hover {
            color: darkred;
            /* Αλλάζει το χρώμα στο hover */
        }
		</style>
	</head>
	<body>
		<div class="container mt-5">
			<h1>Login</h1>
			<?php if(isset($error)) echo '<div class="alert alert-danger">' . $error . '</div>'; ?>
			<form action="" method="post">
				<div class="mb-3">
					<label for="email" class="form-label">Email</label>
					<input type="email" class="form-control" id="email" name="email" required>
				</div>
				<div class="mb-3">
					<label for="password" class="form-label">Password</label>
					<input type="password" class="form-control" id="password" name="password" required>
				</div>
				<button type="submit" class="btn btn-primary">Login</button>
				<a href="register.php" class="btn btn-link">Register</a>
			</form>
		</div>
	</body>
</html>
