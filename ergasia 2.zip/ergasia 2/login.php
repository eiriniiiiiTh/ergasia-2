<?php
    
    session_start();  // Ξεκινάμε μια νέα συνεδρία ή συνεχίζουμε την υπάρχουσα
    
    // Απαιτούμε το αρχείο db.php για τη σύνδεση στη βάση δεδομένων
    require 'ergasia_2.php';  

    // Έλεγχος αν η αίτηση είναι τύπου POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") { 
        
        // Λαμβάνουμε τα δεδομένα από τη φόρμα εισόδου
        $email = $_POST['email'];  // Παίρνουμε το email από τη φόρμα εισόδου
        $password = $_POST['password'];  // Παίρνουμε τον κωδικό από τη φόρμα εισόδου
        
        // Εκτελούμε ερώτημα SQL για την εύρεση του χρήστη βάσει του email
        $query = "SELECT id, fname, lname, password, id_role FROM users WHERE email=?";  // Δημιουργούμε το ερώτημα SQL
        $stmt = $conn->prepare($query);  // Προετοιμάζουμε τη δήλωση
        $stmt->bind_param("s", $email);  // Συνδέουμε το email ως παράμετρο
        $stmt->execute();  // Εκτελούμε τη δήλωση
        $result = $stmt->get_result();  // Παίρνουμε το αποτέλεσμα του ερωτήματος
        
        // Αν υπάρχει μόνο ένας χρήστης με αυτό το email
        if ($result->num_rows == 1) {  // Ελέγχουμε αν βρέθηκε ακριβώς ένας χρήστης
            $row = $result->fetch_assoc();  // Παίρνουμε τα δεδομένα του χρήστη ως συσχετισμένος πίνακας
            
            // Ελέγχουμε αν ο κωδικός είναι σωστός και σύμφωνος με αυτόν στη βάση χρησιμοποιώντας τη συνάρτηση password_verify
            if (password_verify($password, $row['password'])) { 
                
                // Αποθηκεύουμε στη συνεδρία τα στοιχεία του συνδεδεμένου χρήστη
                $_SESSION['user_id'] = $row['id'];  // Αποθηκεύουμε το ID του χρήστη στη συνεδρία
                $_SESSION['user_fname'] = $row['fname'];  // Αποθηκεύουμε το όνομα του χρήστη στη συνεδρία
                $_SESSION['user_role'] = $row['id_role'];  // Αποθηκεύουμε το ρόλο του χρήστη στη συνεδρία
                
                // Ανάλογα με το ρόλο του χρήστη, τον ανακατευθύνουμε στην κατάλληλη σελίδα
                if ($row['id_role'] == 1) {  // Ελέγχουμε αν ο χρήστης είναι διαχειριστής
                    header("Location: admin.php");  // Ανακατευθύνουμε στη σελίδα διαχείρισης
                } else {
                    // Κάτι πήγε στραβά με τον ρόλο του χρήστη, μπορείτε να αντιμετωπίσετε αυτό κατάλληλα
                    // Εδώ μπορείτε να κατευθύνετε τον χρήστη σε μια προεπιλεγμένη σελίδα
                    header("Location: login.php");  // Ανακατευθύνουμε στην αρχική σελίδα
                }
                exit();  // Τερματίζουμε την εκτέλεση του σεναρίου
            } else {
                // Αν ο κωδικός είναι λανθασμένος
                $error = "Invalid email or password";  // Ορίζουμε το μήνυμα λάθους
            }
        } else {
            // Αν δεν βρέθηκε χρήστης με αυτό το email
            $error = "Invalid email or password";  // Ορίζουμε το μήνυμα λάθους
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">  <!-- Ορίζουμε τη κωδικοποίηση χαρακτήρων -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  <!-- Κάνουμε τη σελίδα responsive -->
    <title>Login</title>  <!-- Ορίζουμε τον τίτλο της σελίδας -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">  <!-- Εισάγουμε το Bootstrap CSS -->
    <link rel="stylesheet" href="style.css">  <!-- Εισάγουμε το custom CSS -->
    <style>
        body {
            background-image: url('images/login2.jpg');  /* Ορίζουμε την εικόνα φόντου και μέσα στην παρένθεση αναγράφουμε το path της εικόνας*/
            background-size: contain;  /* Ορίζουμε το μέγεθος της εικόνας να καλύπτει ολόκληρο το φόντο */
            background-repeat: no-repeat;  /* Απενεργοποιούμε την επανάληψη της εικόνας */
            background-position: center top 200px;  /* Ορίζουμε τη θέση της εικόνας στην ιστοσελίδα*/
            
        }

        h1 {
            color: black;  /* Ορίζουμε το χρώμα του τίτλου */
        }

        .form-label {
            color: black;  /* Ορίζουμε το χρώμα της ετικέτας φόρμας */
        }

        .form-control {
            color: white;  /* Ορίζουμε το χρώμα του κειμένου στο input πεδίο */
            background-color: transparent;  /* Κάνουμε το background διάφανο */
            border: 1px solid black;  /* Ορίζουμε το περίγραμμα ως άσπρο */
            padding: 5px;  /* Ορίζουμε την εσωτερική απόσταση */
            margin-bottom: 10px;  /* Ορίζουμε την κάτω απόσταση */
        }

        .btn-primary {
            background-color: orange;  /* Ορίζουμε το χρώμα του κουμπιού */
            border: none;  /* Αφαιρούμε το περίγραμμα του κουμπιού */
            color: black;  /* Ορίζουμε το χρώμα του κειμένου στο κουμπί */
        }

        .btn-primary:hover {
            background-color: darkred;  /* Ορίζουμε το χρώμα του κουμπιού όταν γίνεται hover */
        }

        .btn-link {
            color: orange;  /* Ορίζουμε το χρώμα του συνδέσμου */
        }

        .btn-link:hover {
            color: darkred;  /* Ορίζουμε το χρώμα του συνδέσμου όταν γίνεται hover */
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1>Login</h1>  <!-- Ορίζουμε τον τίτλο της φόρμας εισόδου -->
        <?php if(isset($error)) echo '<div class="alert alert-danger">' . $error . '</div>'; ?>  <!-- Εμφανίζουμε το μήνυμα λάθους αν υπάρχει -->
        <form action="" method="post">  <!-- Δημιουργούμε τη φόρμα εισόδου -->
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>  <!-- Ετικέτα για το πεδίο email -->
                <input type="email" class="form-control" id="email" name="email" required>  <!-- Πεδίο εισόδου για το email -->
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>  <!-- Ετικέτα για το πεδίο κωδικού -->
                <input type="password" class="form-control" id="password" name="password" required>  <!-- Πεδίο εισόδου για τον κωδικό -->
            </div>
            <button type="submit" class="btn btn-primary">Login</button>  <!-- Κουμπί υποβολής φόρμας -->
            <a href="register.php" class="btn btn-link">Register</a>  <!-- Σύνδεσμος για τη σελίδα εγγραφής -->
        </form>
    </div>
</body>
</html>