-- Δημιουργία της βάσης δεδομένων αν δεν υπάρχει ήδη
CREATE DATABASE IF NOT EXISTS ergasia_2;

-- Χρήση της βάσης δεδομένων ergasia_2
USE ergasia_2;

-- Δημιουργία του πίνακα users αν δεν υπάρχει ήδη
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Πρωτεύον κλειδί με αυτόματη αύξηση
    fname VARCHAR(50) NOT NULL,         -- Όνομα χρήστη (μέγιστο 50 χαρακτήρες, δεν μπορεί να είναι κενό)
    lname VARCHAR(50) NOT NULL,         -- Επώνυμο χρήστη (μέγιστο 50 χαρακτήρες, δεν μπορεί να είναι κενό)
    email VARCHAR(100) UNIQUE NOT NULL, -- Ηλεκτρονική διεύθυνση (μοναδική και δεν μπορεί να είναι κενή)
    password VARCHAR(255) NOT NULL,     -- Κωδικός πρόσβασης (μέγιστο 255 χαρακτήρες, δεν μπορεί να είναι κενός)
    id_role INT NOT NULL,               -- Ρόλος χρήστη (αριθμητική τιμή, δεν μπορεί να είναι κενό)
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Ημερομηνία και ώρα δημιουργίας με προεπιλογή την τρέχουσα χρονική στιγμή
);

-- Δημιουργία του πίνακα students
CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,   -- Πρωτεύον κλειδί με αυτόματη αύξηση
    fname VARCHAR(50) NOT NULL,                  -- Όνομα φοιτητή (μέγιστο 50 χαρακτήρες, δεν μπορεί να είναι κενό)
    lname VARCHAR(50) NOT NULL,                  -- Επώνυμο φοιτητή (μέγιστο 50 χαρακτήρες, δεν μπορεί να είναι κενό)
    date_of_birth DATE NOT NULL,                 -- Ημερομηνία γέννησης (δεν μπορεί να είναι κενή)
    gender VARCHAR(10) NOT NULL,                 -- Φύλο (μέγιστο 10 χαρακτήρες, δεν μπορεί να είναι κενό)
    address VARCHAR(255) NOT NULL,               -- Διεύθυνση (μέγιστο 255 χαρακτήρες, δεν μπορεί να είναι κενή)
    phone VARCHAR(20) NOT NULL,                  -- Τηλέφωνο (μέγιστο 20 χαρακτήρες, δεν μπορεί να είναι κενό)
    email VARCHAR(100) UNIQUE NOT NULL,          -- Ηλεκτρονική διεύθυνση (μοναδική και δεν μπορεί να είναι κενή)
    enrollment_date DATE NOT NULL,               -- Ημερομηνία εγγραφής (δεν μπορεί να είναι κενή)
    program VARCHAR(100) NOT NULL,               -- Πρόγραμμα σπουδών (μέγιστο 100 χαρακτήρες, δεν μπορεί να είναι κενό)
    year_of_study INT NOT NULL,                  -- Έτος σπουδών (αριθμητική τιμή, δεν μπορεί να είναι κενή)
    emergency_contact VARCHAR(100) NOT NULL      -- Επείγουσα επαφή (μέγιστο 100 χαρακτήρες, δεν μπορεί να είναι κενή)
);

-- Εισαγωγή δεδομένων στον πίνακα users
INSERT INTO `users` VALUES ('1', 'Μαρία', 'Διαχειρίστρια', 'admin@gmail.com', '$2y$12$WGgq06pzMp2Oc5Lavvc1GuH5NrtDjBnmp2befkWCoHAnlKrWzjYpW', '1', '2024-04-26 07:13:12');