CREATE DATABASE IF NOT EXISTS ergasia_2;

USE ergasia_2;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    id_role INT NOT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(10) NOT NULL,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    enrollment_date DATE NOT NULL,
    program VARCHAR(100) NOT NULL,
    year_of_study INT NOT NULL,
    emergency_contact VARCHAR(100) NOT NULL
);



INSERT INTO `users` VALUES ('1', 'Μαρία', 'Διαχειρίστρια', 'admin@gmail.com', '$2y$12$WGgq06pzMp2Oc5Lavvc1GuH5NrtDjBnmp2befkWCoHAnlKrWzjYpW', '1', '2024-04-26 07:13:12');
