<?php
// Ορισμός μεταβλητών για τη σύνδεση στη βάση δεδομένων
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ergasia_2";

// Δημιουργία σύνδεσης στη βάση δεδομένων
$conn = new mysqli($servername, $username, $password, $dbname);

// Έλεγχος σύνδεσης
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); // Αν αποτύχει η σύνδεση, εκτύπωση μηνύματος σφάλματος και τερματισμός εκτέλεσης
}

// Δημιουργία πίνακα αν δεν υπάρχει
$conn->query("
    CREATE TABLE IF NOT EXISTS students (
        student_id INT PRIMARY KEY AUTO_INCREMENT,
        fname VARCHAR(255) NOT NULL,
        lname VARCHAR(255) NOT NULL,
        date_of_birth DATE NOT NULL,
        gender VARCHAR(50),
        address VARCHAR(255),
        phone VARCHAR(20),
        email VARCHAR(255),
        enrollment_date DATE,
        program VARCHAR(50),
        year_of_study INT,
        emergency_contact VARCHAR(20)
    )
");

$table_data = ''; // Αρχικοποίηση μεταβλητής για τα δεδομένα του πίνακα
$file_uploaded = false; // Αρχικοποίηση μεταβλητής που δείχνει αν έχει γίνει μεταφόρτωση αρχείου

// Έλεγχος για πρώτη φόρτωση
if (!isset($_COOKIE['first_load_done'])) {
    // Διαγραφή όλων των εγγραφών από τον πίνακα πριν την πρώτη φόρτωση
    $conn->query("DELETE FROM students");
    setcookie('first_load_done', '1', time() + 3600); // Ορισμός cookie για μία ώρα
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
        $file = $_FILES['file']['tmp_name']; // Λήψη του προσωρινού ονόματος του αρχείου
        $file_uploaded = true; // Ορισμός της μεταβλητής για την μεταφόρτωση αρχείου ως true

        if (($handle = fopen($file, "r")) !== FALSE) {
            fgetcsv($handle); // Ανάγνωση της κεφαλίδας (πρώτη γραμμή)
            
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                // Ανάθεση τιμών από κάθε γραμμή του CSV σε μεταβλητές
                $student_id = intval($data[0]);
                $fname = $data[1];
                $lname = $data[2];
                $date_of_birth = $data[3];
                $gender = $data[4];
                $address = $data[5];
                $phone = $data[6];
                $email = $data[7];
                $enrollment_date = $data[8];
                $program = $data[9];
                $year_of_study = intval($data[10]);
                $emergency_contact = $data[11];

                // Έλεγχος για διπλό student_id ή email
                $stmt = $conn->prepare("SELECT student_id FROM students WHERE student_id = ? OR email = ?");
                $stmt->bind_param("is", $student_id, $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Ανάκτηση του μέγιστου student_id και δημιουργία νέου student_id
                    $result_max_id = $conn->query("SELECT MAX(student_id) AS max_id FROM students");
                    $row_max_id = $result_max_id->fetch_assoc();
                    $student_id = $row_max_id['max_id'] + 1;
                }

                // Εισαγωγή νέας εγγραφής
                $stmt = $conn->prepare("
                    INSERT INTO students (student_id, fname, lname, date_of_birth, gender, address, phone, email, enrollment_date, program, year_of_study, emergency_contact)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param("isssssssssis", $student_id, $fname, $lname, $date_of_birth, $gender, $address, $phone, $email, $enrollment_date, $program, $year_of_study, $emergency_contact);
                $stmt->execute(); // Εκτέλεση της δήλωσης
            }
            fclose($handle); // Κλείσιμο του αρχείου
        }
    }
}

// Ανάκτηση δεδομένων από τον πίνακα
$result = $conn->query("SELECT * FROM students");

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $table_data .= '<tr>';
        $table_data .= '<td>' . htmlspecialchars($row['student_id']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['fname']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['lname']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['date_of_birth']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['gender']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['address']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['phone']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['email']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['enrollment_date']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['program']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['year_of_study']) . '</td>';
        $table_data .= '<td>' . htmlspecialchars($row['emergency_contact']) . '</td>';
        $table_data .= '</tr>';
    }
} else {
    $table_data = '<tr><td colspan="12">No records found</td></tr>'; // Μήνυμα αν δεν βρεθούν εγγραφές
}

$conn->close(); // Κλείσιμο της σύνδεσης
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse; /* Κατάργηση των κελιών του πίνακα */
        }
        table, th, td {
            border: 1px solid black; /* Προσθήκη μαύρου περιγράμματος στον πίνακα, τις κεφαλίδες και τα κελιά */
        }
        th, td {
            padding: 8px; /* Προσθήκη εσωτερικού περιθωρίου 8px στις κεφαλίδες και τα κελιά */
            text-align: left; /* Στοίχιση κειμένου στα αριστερά */
        }
        .container {
            margin-left: 20px; /* Μετακίνηση του περιεχομένου προς τα δεξιά */
        }
        body {
            background-image: url('images/eikona4.jpg'); /* Προσθήκη εικόνας φόντου */
            background-size: cover; /* Κάλυψη ολόκληρης της επιφάνειας με την εικόνα */
            background-repeat: no-repeat; /* Αποφυγή επανάληψης της εικόνας */
            background-position: center top 5px; /* Τοποθέτηση της εικόνας στο κέντρο και 5px από την κορυφή */
        }
    </style>
</head>
<body>
    <?php if ($file_uploaded): ?>
        <div class="container">
            <h2>Students Table</h2>
            <table>
                <tr>
                    <th>Student ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Date of Birth</th>
                    <th>Gender</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Enrollment Date</th>
                    <th>Program</th>
                    <th>Year of Study</th>
                    <th>Emergency Contact</th>
                </tr>
                <?php echo $table_data; ?> <!-- Εμφάνιση των δεδομένων του πίνακα -->
            </table>
        </div>
    <?php endif; ?>
</body>

</html>
