<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ergasia_2";

// Δημιουργία σύνδεσης στη βάση δεδομένων
$conn = new mysqli($servername, $username, $password, $dbname);

// Έλεγχος σύνδεσης
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Δημιουργία πίνακα αν δεν υπάρχει
$conn->query("
    CREATE TABLE IF NOT EXISTS students (
        student_id VARCHAR(255) PRIMARY KEY,
        fname VARCHAR(255) NOT NULL,
        lname VARCHAR(255) NOT NULL,
        date_of_birth DATE NOT NULL,
        gender VARCHAR(50),
        address VARCHAR(255),
        phone VARCHAR(20),
        email VARCHAR(255),
        enrollment_date DATE,
        program VARCHAR(50),
        year_of_study INT,
        emergency_contact VARCHAR(20)
    )
");

$table_data = '';
$file_uploaded = false;
$csv_students = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
        $file = $_FILES['file']['tmp_name'];
        $file_uploaded = true;

        if (($handle = fopen($file, "r")) !== FALSE) {
            fgetcsv($handle); // Ανάγνωση της κεφαλίδας (πρώτη γραμμή)
            
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $student_id = $data[0];
                $fname = $data[1];
                $lname = $data[2];
                $date_of_birth = $data[3];
                $gender = $data[4];
                $address = $data[5];
                $phone = $data[6];
                $email = $data[7];
                $enrollment_date = $data[8];
                $program = $data[9];
                $year_of_study = $data[10];
                $emergency_contact = $data[11];
                $csv_students[] = $student_id;

                // Εισαγωγή ή ενημέρωση εγγραφής
                $stmt = $conn->prepare("
                    INSERT INTO students (student_id, fname, lname, date_of_birth, gender, address, phone, email, enrollment_date, program, year_of_study, emergency_contact)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                        fname = VALUES(fname),
                        lname = VALUES(lname),
                        date_of_birth = VALUES(date_of_birth),
                        gender = VALUES(gender),
                        address = VALUES(address),
                        phone = VALUES(phone),
                        email = VALUES(email),
                        enrollment_date = VALUES(enrollment_date),
                        program = VALUES(program),
                        year_of_study = VALUES(year_of_study),
                        emergency_contact = VALUES(emergency_contact)
                ");
                $stmt->bind_param("ssssssssssii", $student_id, $fname, $lname, $date_of_birth, $gender, $address, $phone, $email, $enrollment_date, $program, $year_of_study, $emergency_contact);
                $stmt->execute();
            }
            fclose($handle);
        }
        
    }
}
// Διαγραφή των εγγραφών που δεν υπάρχουν πλέον στο CSV
if ($file_uploaded && !empty($csv_students)) {
    $csv_students_placeholder = implode(',', array_fill(0, count($csv_students), '?'));
    $stmt_delete = $conn->prepare("
        DELETE FROM students WHERE student_id NOT IN ($csv_students_placeholder)
    ");
    $stmt_delete->bind_param(str_repeat('s', count($csv_students)), ...$csv_students);
    $stmt_delete->execute();
}

// Ανάκτηση δεδομένων από τον πίνακα
if ($file_uploaded) {
    $result = $conn->query("SELECT * FROM students");

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $table_data .= '<tr>';
            $table_data .= '<td>' . htmlspecialchars($row['student_id']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['fname']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['lname']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['date_of_birth']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['gender']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['address']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['phone']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['email']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['enrollment_date']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['program']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['year_of_study']) . '</td>';
            $table_data .= '<td>' . htmlspecialchars($row['emergency_contact']) . '</td>';
            $table_data .= '</tr>';
        }
    } else {
        $table_data = '<tr><td colspan="12">No records found</td></tr>';
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        .container {
    margin-left: 20px; /* Μετακινεί τα περιεχόμενα προς τα δεξιά */
        }
        body {

    background-image: url('images/eikona4.jpg');
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center top 5px;
        }
        
    </style>
</head>

    <?php if ($file_uploaded): ?>
        <div class="container">
        <h2>Students Table</h2>
        <table>
            <tr>
                <th>Student ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Date of Birth</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Enrollment Date</th>
                <th>Program</th>
                <th>Year of Study</th>
                <th>Emergency Contact</th>
            </tr>
            <?php echo $table_data; ?>
        </table>
    <?php endif; ?>
    </div>
    <br></br>
    
   
</body>
</html>