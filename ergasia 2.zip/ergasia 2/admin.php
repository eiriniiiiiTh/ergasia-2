<?php
    // Απαιτούμε το αρχείο check.php για να ελέγξουμε τη σύνδεση και τον ρόλο του χρήστη
	require 'check.php';
	
	// Απαιτούμε το αρχείο upload.php για να ενεργοποιήσουμε τη λειτουργία ανεβάσματος αρχείων
	require 'upload.php';
	
	// Καλούμε τη συνάρτηση checkLoginAndRole με παράμετρο τον ρόλο 1 (Διαχειριστής)
	checkLoginAndRole(1);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8"> <!-- Ορισμός της κωδικοποίησης χαρακτήρων σε UTF-8 -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Ρύθμιση της προβολής για να ταιριάζει με την οθόνη της συσκευής -->
		<title>Admin Page</title> <!-- Τίτλος της σελίδας -->
		<link rel="stylesheet" href="style.css"> <!-- Σύνδεση με το αρχείο CSS -->
		<style>

		
		button {
			padding: 10px 20px; /* Εσωτερικό περιθώριο του κουμπιού */
			font-size: 16px; /* Μέγεθος γραμματοσειράς του κουμπιού */
			border: none; /* Χωρίς περιθώριο γύρω από το κουμπί */
			cursor: pointer; /* Ο δείκτης του ποντικιού γίνεται δείκτης-κέρσορας όταν βρίσκεται πάνω από το κουμπί */
			border-radius: 0px 0px 5px 15px; /* Καμπυλότητα των γωνιών του κουμπιού */
		}

		.container { /* Αφορά την κλάση container*/
			margin-left: 20px; /* Μετακινεί τα περιεχόμενα προς τα δεξιά */
		}

		h1 { /* Αφορά την επικεφαλίδα h1*/
			color: black; /* Το χρώμα του κειμένου των επικεφαλίδων είναι μαύρο */
		}


		.btn-upload {
			background-color: blue; /* Κάνει το κουμπί ανεβάσματος blue */
			color: white; /* Το χρώμα του κειμένου είναι λευκό */
			border: none; /* Χωρίς περίγραμμα γύρω από το κουμπί */
			padding: 10px 20px; /* Εσωτερικό περιθώριο του κουμπιού */
			cursor: pointer; /* Ο δείκτης του ποντικιού γίνεται δείκτης-κέρσορας όταν βρίσκεται πάνω από το κουμπί */
			font-size: 16px; /* Μέγεθος γραμματοσειράς του κουμπιού */
			margin: 5px; /* Περιθώριο γύρω από το κουμπί */
		}

		.btn-upload:hover {
			background-color: darkblue; /* Το χρώμα του κουμπιού όταν ο δείκτης βρίσκεται πάνω από το κουμπί γίνεται darkblue */
			color: white; /* Το χρώμα του κειμένου παραμένει λευκό */
		}

		.logout-link {
			color: black; /* Κάνει το σύνδεσμο αποσύνδεσης μαύρο */
		}

		body {
			background-image: url('images/uploadicon.jpg'); /* Ορίζω ως φόντο εικόνα και μέσα στην παρένθεση αναγράφεται το path - η διαδρομή  */
			background-size: contain; /* Η εικόνα φόντου καλύπτει ολόκληρη την επιφάνεια */
			background-repeat: no-repeat; /* Η εικόνα φόντου δεν επαναλαμβάνεται */
			background-position: center top 0px; /* Η εικόνα φόντου τοποθετείται στο κέντρο και επάνω */
		}

		</style>
	</head>
	<body>
		<div class="container">
			<h1>Welcome Admin <?php echo $_SESSION['user_fname']; ?></h1> <!-- Εμφανίζει ένα μήνυμα καλωσορίσματος με το όνομα του διαχειριστή -->
			<h1>Upload CSV File</h1> <!-- Επικεφαλίδα για το τμήμα ανεβάσματος αρχείων -->
			<form action="upload.php" method="post" enctype="multipart/form-data"> <!-- Φόρμα για την αποστολή αρχείων -->
				<input type="file" name="file" accept=".csv"> <!-- Πεδίο επιλογής αρχείων, επιτρέποντας μόνο αρχεία CSV -->
				<button type="submit" class="btn btn-upload">Upload</button> <!-- Κουμπί υποβολής για την αποστολή του αρχείου -->
			</form>
			<br> </br> <!-- Κενό διάστημα μεταξύ των στοιχείων της σελίδας -->
			<a href="logout.php" class="btn logout-link">Logout</a> <!-- Σύνδεσμος αποσύνδεσης -->
		</div>
	</body>
</html>