<?php
	// Απαιτούμε το αρχείο check.php για να ελέγξουμε τη σύνδεση και τον ρόλο του χρήστη
	
	require 'check.php';
	require 'upload.php';
	
	// Καλούμε τη συνάρτηση checkLoginAndRole με παράμετρο τον ρόλο 1 (Διαχειριστής)
	checkLoginAndRole(1);
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Admin Page</title>
		<link rel="stylesheet" href="style.css">
		<style>

		body {

background-image: url('images/eikona1.jpg');
background-size: cover;
background-repeat: no-repeat;
background-position: center top 0px;
}
button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 0px 0px 5px 15px;
}

.container {
    margin-left: 20px; /* Μετακινεί τα περιεχόμενα προς τα δεξιά */
}

h1 {
    color: white;
}

.file-input {
    background-color: darkred; /* Κάνει το κουμπί επιλογής αρχείου darkred */
    color: white;
    border: none;
    padding: 10px;
    margin-bottom: 10px;
}

.btn-upload {
    background-color: darkred; /* Κάνει το κουμπί upload darkred */
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    font-size: 16px;
    margin: 5px;
}

.btn-upload:hover {
    background-color: darkred;
    color: white;
}

.logout-link {
    color: white; /* Κάνει το link logout άσπρο */
}
body {

background-image: url('images/eikona3.jpg');
background-size: cover;
background-repeat: no-repeat;
background-position: center top 0px;
}

		</style>
	</head>
	<body>
		<div class="container">
		<h1>Welcome Admin <?php echo $_SESSION['user_fname']; ?></h1>
				<h1>Upload CSV File</h1>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <input type="file" name="file" accept=".csv">
        <button type="submit" class="btn btn-upload">Upload</button>
    </form>
	<br> </br>
    <a href="logout.php" class="btn logout-link">Logout</a>
</div>
	</body>
</html>





