<?php
// Ορισμός μεταβλητών για τη σύνδεση στη βάση δεδομένων
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ergasia_2";

// Δημιουργία σύνδεσης στη βάση δεδομένων
$conn = new mysqli($servername, $username, $password, $dbname);

// Έλεγχος σύνδεσης
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error); // Αν αποτύχει η σύνδεση, εκτύπωση μηνύματος σφάλματος και τερματισμός εκτέλεσης
}

// Διαγραφή όλων των εγγραφών από τον πίνακα
$conn->query("DELETE FROM students");

$conn->close();
	// Ξεκινάμε τη συνεδρία PHP
	session_start();
	// Απενεργοποιούμε και διαγράφουμε όλα τα δεδομένα συνεδρίας
	session_unset();
	session_destroy();
	// Ανακατευθύνουμε τον χρήστη στη σελίδα σύνδεσης (login.php)
	header("Location: login.php");
	// Τερματίζουμε την εκτέλεση του κώδικα
	exit();
?>

